import * as THREE from '../build/three.module.js';
import { GLTFLoader } from "../jsm/loaders/GLTFLoader.js";
import { OrbitControls } from '../jsm/controls/OrbitControls.js';
import Stats from '../jsm/libs/stats.module.js';


let textureEquirec;
let stats, camera, renderer, scene, cubeCamera, materialReflective, cubeRenderTarget;
//models
let mainScene;

// Canvas
const canvas = document.querySelector('canvas.webgl')

const textureLoader = new THREE.TextureLoader();

textureEquirec = textureLoader.load( './assets/3d/hdri.jpg', function(texture){
	texture.encoding = THREE.sRGBEncoding;
	texture.mapping = THREE.EquirectangularReflectionMapping;
	init( texture );
	animate();
} );


stats = new Stats();
stats.showPanel( 0 );
//document.body.appendChild( stats.dom );

//3D models
const loader = new GLTFLoader().setPath('./assets/3d/');

//init
function init( texture ){
	
	//camera
	camera = new THREE.PerspectiveCamera( 28, window.innerWidth / window.innerHeight, 0.1, 40 );
	camera.position.set(0, 0, 10);
	camera.lookAt( 0, 0, 0.2 );
	

	//cubeCamera Reflections
	cubeRenderTarget = new THREE.WebGLCubeRenderTarget(64);
	cubeCamera = new THREE.CubeCamera(1, 100, cubeRenderTarget);
	
	//Renderer
	renderer = new THREE.WebGLRenderer({
		canvas: canvas,
		antialias: true,
		alpha: true
	});
	renderer.setPixelRatio( window.devicePixelRatio );
	renderer.setSize( window.innerWidth, window.innerHeight );
	renderer.outputEncoding = THREE.sRGBEncoding;
	renderer.powerPreference = "low-power";
	document.body.appendChild( renderer.domElement );

	/**
 	*Sizes*/
	 const sizes = {
		width: window.innerWidth,
		height: window.innerHeight
	}

	scene = new THREE.Scene();
	//scene.background = new THREE.Color(0xe9eaeb);
	scene.environment = textureEquirec;
	//scene.environment = cubeCamera.renderTarget.texture;
	//scene.fog = new THREE.FogExp2( 0xB5B5B5, 0.01 );


	window.addEventListener('resize', () =>
	{
		// Update sizes
		sizes.width = window.innerWidth;
		sizes.height = window.innerHeight;


		// Update camera
		camera.aspect = sizes.width / sizes.height
		camera.updateProjectionMatrix();

		// Update renderer
		renderer.setSize(sizes.width, sizes.height);
		renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
	});

	//3D models
	
	loader.load( 'scene.glb', function ( gltf ) {
		//model = gltf.scene;
		//document.querySelector('.loader').classList.add('loader-fade');		
		mainScene = gltf.scene
		//mainScene.castShadow = true;
		scene.add( mainScene );
		
	}, 
	(xhr) => {
        console.log(Math.floor((xhr.loaded / xhr.total) * 100) + '% loaded');
		//document.getElementById('load-percent').innerText = Math.floor((xhr.loaded / xhr.total) * 100) + '% Loading...';
    },
	undefined, function ( error ) {
		console.error( error );
	} );

	//scene.add( ambientLight );
	//scene.add( hemiLight );
	//scene.add( dirLight );
	const geometry = new THREE.BoxGeometry(0.01, 0.01, 0.01);
	const material = new THREE.MeshBasicMaterial( { color: 0x00ff00 } );
	const cube = new THREE.Mesh( geometry, material );
	cube.position.set(0, 0.04,0.8)
	//scene.add( cube );
}

//lights 
const dirLight = new THREE.DirectionalLight( 0xFFE6C1 );
dirLight.position.set( 60, 60, -60 );
dirLight.castShadow = true;
dirLight.shadow.mapSize.width = 128; // default
dirLight.shadow.mapSize.height = 128; // default
dirLight.shadow.camera.near = 0.5; // default
dirLight.shadow.camera.far = 500; 

//
const ambientLight = new THREE.AmbientLight( 0x13131e );
const hemiLight = new THREE.HemisphereLight(0xffeeb1, 0x080820, 1);

	
 
function lerp(x, y, a) {
    return (1 - a) * x + a * y
}

// Used to fit the lerps to start and end at specific scrolling percentages
function scalePercent(start, end) {
    return (scrollPercent - start) / (end - start)
}

const animationScripts = []

//add an animation that moves the cube through first 40 percent of scroll
/*animationScripts.push({
    start: 0,
    end: 0,
    func: () => {
        camera.lookAt(mainScene.position)
		mainScene.rotation.x = lerp(0, 0, scalePercent(0, 1));
		//mainScene.rotation.z = lerp(0, 0, scalePercent(0, 1));
    },
})*/

animationScripts.push({
    start: 0,
    end: 20,
    func: () => {
        //camera.lookAt.z = lerp(0,0.2, scalePercent(0, 20));
		camera.lookAt(0,0,0)
		mainScene.rotation.y += 0.01;
		mainScene.rotation.z += 0.001;
		mainScene.position.x = lerp(0,3, scalePercent(0,20));
		/*mainScene.position.y = lerp(-1, 0, scalePercent(0, 20));
		mainScene.rotation.x = lerp(0, 0, scalePercent(0, 20));
		mainScene.rotation.z = lerp(0, 0, scalePercent(0, 20));*/
		mainScene.position.z = lerp(3,1, scalePercent(0, 20));
    },
})
animationScripts.push({
    start: 20,
    end: 40,
    func: () => {
        //camera.lookAt.z = lerp(0,0.2, scalePercent(0, 20));
		mainScene.rotation.y += 0.01;		
		mainScene.rotation.z += 0.001;
		mainScene.position.x = lerp(3,3, scalePercent(21,40));
		mainScene.position.z = lerp(1,1, scalePercent(21, 40));
		/*mainScene.position.y = lerp(0, -0.02, scalePercent(21, 40));
		mainScene.rotation.x = lerp(0, 1.8, scalePercent(21, 40));
		mainScene.rotation.z = lerp(0, -0.2, scalePercent(21, 40));*/
		
    },
})

animationScripts.push({
    start: 40,
    end: 60,
    func: () => {
		mainScene.rotation.y += 0.01;
		mainScene.rotation.z += 0.001;
		mainScene.position.x = lerp(3,3, scalePercent(41, 60));
		mainScene.position.z = lerp(1,1, scalePercent(41, 60));
        //camera.lookAt(0,0,0)
		//camera.position.set = (0,2,0);
		//mainScene.position.z = lerp(0,1,scalePercent(0, 10)
		/*mainScene.position.x = lerp(0,0.2, scalePercent(41, 60));
		mainScene.position.z = lerp(0.5,-0.2, scalePercent(41, 60));
		mainScene.rotation.z = lerp(-0.2, -0.6, scalePercent(41, 60));*/
    },
})
animationScripts.push({
    start: 60,
    end: 80,
    func: () => {
		mainScene.rotation.y += 0.01;
		mainScene.rotation.z += 0.001;
		mainScene.position.x = lerp(3,3, scalePercent(60, 80));
		mainScene.position.z = lerp(1,1, scalePercent(60, 80));
        //camera.lookAt(0,0.2,0)
		//camera.position.set = (0,2,0);
		//camera.position.y = lerp(0,-0.1, scalePercent(41, 60));
    },
})
animationScripts.push({
    start: 80,
    end: 101,
    func: () => {
		mainScene.rotation.y += 0.01;
		mainScene.rotation.z += 0.001;
		mainScene.position.x = lerp(3,3, scalePercent(80, 100));
		mainScene.position.z = lerp(1,1, scalePercent(80, 100));
        //camera.lookAt(0,0.2,0)
		//camera.position.set = (0,2,0);
		//camera.position.y = lerp(0,-0.1, scalePercent(41, 60));
    },
})

function playScrollAnimations() {
    animationScripts.forEach((a) => {
        if (scrollPercent >= a.start && scrollPercent < a.end) {
            a.func()
        }
    })
}

let scrollPercent = 0

document.body.onscroll = () => {
    //calculate the current scroll progress as a percentage
    scrollPercent = (
		(document.documentElement.scrollTop || document.body.scrollTop) / ((document.documentElement.scrollHeight || document.body.scrollHeight) - document.documentElement.clientHeight)	) * 100;
	document.getElementById('scrollProgress').innerText =
        'Scroll Progress : ' + scrollPercent.toFixed(2) + ' X rotation : ' + mainScene.rotation.x
}



function animate() {
	
	requestAnimationFrame(animate);
	playScrollAnimations()
	render();
	stats.end();
	
}


function render(){
	renderer.render(scene, camera);
}
window.scrollTo({ top: 0, behavior: 'smooth' })